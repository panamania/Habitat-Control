// server/platforms/azure-ai-foundry.mjs
//
// Azure AI Foundry's Agent Service speaks the OpenAI-Assistants-compatible
// protocol: agents = /assistants, conversations = /threads, executions =
// /threads/{id}/runs. The catch, and it's a real one: that protocol has no
// "list every thread" endpoint. Threads are only reachable by ID, so unless
// you're already recording thread IDs somewhere when you create them,
// there's nothing for this adapter to enumerate from Foundry's own API.
//
// The practical fix is to read run telemetry back out of Azure Monitor /
// Application Insights instead — Foundry agents emit run start/finish/fail
// traces there once diagnostic settings are turned on for the project, and
// Log Analytics *is* queryable in bulk. That's what this adapter does.
//
// Prerequisite: turn on diagnostic export to a Log Analytics workspace in
// the Foundry project's Monitoring blade — without that, this returns
// nothing to query against. The KQL below assumes the standard AppTraces
// shape with the agent name / thread / run / status logged as custom
// dimensions; adjust the field names to whatever your own diagnostic
// setting actually exports.

import { DefaultAzureCredential } from '@azure/identity';
import { LogsQueryClient } from '@azure/monitor-query';
import { createPolledCache } from './cache.mjs';

const WORKSPACE_ID = process.env.AZURE_LOG_ANALYTICS_WORKSPACE_ID;
const PROJECT_ENDPOINT = process.env.AZURE_AI_FOUNDRY_PROJECT_ENDPOINT; // https://<project>.services.ai.azure.com
const FOUNDRY_PORTAL_URL = process.env.AZURE_AI_FOUNDRY_PORTAL_URL; // ai.azure.com project URL, for openThread

const credential = new DefaultAzureCredential();
const logsClient = new LogsQueryClient(credential);

const KQL = `
AppTraces
| where TimeGenerated > ago(1h)
| where Message has "AgentRun"
| extend agentName = tostring(Properties.agentName),
         threadId = tostring(Properties.threadId),
         runId = tostring(Properties.runId),
         status = tostring(Properties.status)
| summarize lastActivityAt = arg_max(TimeGenerated, *) by runId
`;

async function fetchThreads() {
  if (!WORKSPACE_ID) return [];
  const result = await logsClient.queryWorkspace(WORKSPACE_ID, KQL, { duration: 'PT1H' });
  const table = result.tables?.[0];
  if (!table) return [];
  const columns = table.columnDescriptors.map((c) => c.name);

  return table.rows.map((row) => {
    const r = Object.fromEntries(columns.map((c, i) => [c, row[i]]));
    const lastActivityMs = new Date(r.lastActivityAt).getTime();
    return {
      id: `azure-ai-foundry:${r.runId}`,
      title: r.agentName ?? 'Untitled agent',
      preview: '',
      project: `azure:${r.agentName ?? 'unknown'}`,
      projectPath: '',
      worktree: '',
      cwd: '',
      gitBranch: '',
      model: '',
      effort: '',
      createdAt: lastActivityMs,
      lastActivityAt: lastActivityMs,
      lastFocusedAt: 0,
      running: r.status === 'in_progress' || r.status === 'queued',
      unread: r.status === 'requires_action', // closest analogue to "waiting on you"
      hasError: r.status === 'failed' || r.status === 'expired',
      archived: r.status === 'completed' || r.status === 'cancelled',
      sizeBytes: 0,
      source: 'azure-ai-foundry',
      canOpen: Boolean(FOUNDRY_PORTAL_URL),
      ref: { threadId: r.threadId, runId: r.runId },
    };
  });
}

const cache = createPolledCache(fetchThreads, { ttlMs: 30_000, label: 'azure-ai-foundry' });

export default {
  id: 'azure-ai-foundry',
  name: 'Azure AI Foundry',
  async detect() {
    return Boolean(WORKSPACE_ID && PROJECT_ENDPOINT);
  },
  async scanThreads() {
    return cache.get();
  },
  openThread({ threadId }) {
    if (!FOUNDRY_PORTAL_URL) return { ok: false, error: 'AZURE_AI_FOUNDRY_PORTAL_URL not set.' };
    return { ok: true, url: `${FOUNDRY_PORTAL_URL}/threads/${threadId}` };
  },
  newSession() {
    return { ok: false, error: 'Starting a new Foundry thread from here is not wired up yet.' };
  },
};
