// server/platforms/gcp-vertex-agents.mjs
//
// Vertex AI Agent Builder's "Agent Engine" (formerly Reasoning Engine) has
// a real list-sessions endpoint, unlike Azure's Assistants-style API — so
// this is the most direct of the three cloud adapters:
//
//   GET /v1beta1/projects/{p}/locations/{l}/reasoningEngines/{engineId}/sessions
//
// One engine can serve many agents depending on how you've structured a
// deployment, so `project` below groups by *engine* — if you deploy one
// engine per business agent (the common pattern) this gives you one zone
// per agent, same as the Bedrock and Foundry adapters.
//
// Vertex has no cheap "list every engine with sessions across every
// location" call, so this adapter is deliberately told which engines to
// watch via GCP_AGENT_ENGINE_IDS rather than trying to discover them.

import { GoogleAuth } from 'google-auth-library';
import { createPolledCache } from './cache.mjs';

const PROJECT_ID = process.env.GCP_PROJECT_ID;
const LOCATION = process.env.GCP_LOCATION || 'us-central1';
const ENGINE_IDS = (process.env.GCP_AGENT_ENGINE_IDS || '').split(',').filter(Boolean);

const auth = new GoogleAuth({ scopes: 'https://www.googleapis.com/auth/cloud-platform' });

async function authedFetch(url) {
  const client = await auth.getClient();
  const { token } = await client.getAccessToken();
  const res = await fetch(url, { headers: { Authorization: `Bearer ${token}` } });
  if (!res.ok) throw new Error(`${res.status} ${await res.text()}`);
  return res.json();
}

async function fetchThreads() {
  const threads = [];
  for (const engineId of ENGINE_IDS) {
    const base = `https://${LOCATION}-aiplatform.googleapis.com/v1beta1/projects/${PROJECT_ID}/locations/${LOCATION}/reasoningEngines/${engineId}`;
    let sessions = [];
    try {
      const data = await authedFetch(`${base}/sessions`);
      sessions = data.sessions ?? [];
    } catch (err) {
      console.error(`[gcp-vertex-agents] ${engineId}:`, err.message);
      continue; // one bad engine shouldn't cost you every other engine's threads
    }

    for (const session of sessions) {
      const sessionId = session.name.split('/').pop();
      const updateMs = new Date(session.updateTime ?? session.createTime).getTime();
      threads.push({
        id: `gcp-vertex:${engineId}:${sessionId}`,
        title: session.displayName || `Session ${sessionId.slice(0, 8)}`,
        preview: '',
        project: `gcp:${engineId}`,
        projectPath: '',
        worktree: LOCATION,
        cwd: '',
        gitBranch: '',
        model: '',
        effort: '',
        createdAt: new Date(session.createTime).getTime(),
        lastActivityAt: updateMs,
        lastFocusedAt: 0,
        running: Date.now() - updateMs < 30_000,
        unread: false,
        hasError: false, // the session resource itself has no status enum — pull this from session events if you need it
        archived: false,
        sizeBytes: JSON.stringify(session.sessionState ?? {}).length,
        source: 'gcp-vertex-agents',
        canOpen: true,
        ref: { engineId, sessionId },
      });
    }
  }
  return threads;
}

const cache = createPolledCache(fetchThreads, { ttlMs: 30_000, label: 'gcp-vertex-agents' });

export default {
  id: 'gcp-vertex-agents',
  name: 'GCP Vertex AI Agent Builder',
  async detect() {
    return Boolean(PROJECT_ID && ENGINE_IDS.length);
  },
  async scanThreads() {
    return cache.get();
  },
  openThread({ engineId, sessionId }) {
    return {
      ok: true,
      url: `https://console.cloud.google.com/vertex-ai/agents/agent-engines/${engineId}/sessions/${sessionId}?project=${PROJECT_ID}`,
    };
  },
  newSession() {
    return { ok: false, error: 'Starting a new Vertex session from here is not wired up yet.' };
  },
};
