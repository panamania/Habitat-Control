// server/platforms/k8s-agents.mjs
//
// For self-hosted agents there's no single vendor API to target — this
// assumes the common convention of running each agent as a Deployment/Job
// whose Pods carry a label identifying which agent they belong to, and
// that something in your stack keeps an `agent-colony/status` annotation
// current (running | waiting | error | done). That annotation is the one
// piece this file can't invent for you — write it from your agent's own
// lifecycle hooks, a sidecar, or a small controller that watches your
// existing logs/metrics and patches the pod.
//
// This is the adapter most worth treating as a starting point rather than
// a finished one — swap the label selector and the status source for
// whatever your actual convention already is.

import * as k8s from '@kubernetes/client-node';
import { createPolledCache } from './cache.mjs';

const NAMESPACE = process.env.K8S_AGENT_NAMESPACE || 'agents';
const LABEL_SELECTOR = process.env.K8S_AGENT_LABEL_SELECTOR || 'app.kubernetes.io/component=agent';

const kc = new k8s.KubeConfig();
kc.loadFromDefault(); // in-cluster config when deployed, ~/.kube/config locally
const coreApi = kc.makeApiClient(k8s.CoreV1Api);

async function fetchThreads() {
  const { body } = await coreApi.listNamespacedPod(
    NAMESPACE, undefined, undefined, undefined, undefined, LABEL_SELECTOR
  );

  return body.items.map((pod) => {
    const labels = pod.metadata.labels ?? {};
    const annotations = pod.metadata.annotations ?? {};
    const agentName = labels['agent-colony/agent-name'] ?? labels.app ?? 'unknown-agent';
    const status = annotations['agent-colony/status'] ?? '';
    const phase = pod.status?.phase; // Pending / Running / Succeeded / Failed / Unknown
    const startedAt = pod.status?.startTime ? new Date(pod.status.startTime).getTime() : Date.now();

    return {
      id: `k8s:${pod.metadata.namespace}:${pod.metadata.name}`,
      title: agentName,
      preview: '',
      project: `k8s:${agentName}`,
      projectPath: '',
      worktree: pod.metadata.namespace,
      cwd: '',
      gitBranch: '',
      model: labels['agent-colony/model'] ?? '',
      effort: '',
      createdAt: startedAt,
      lastActivityAt: startedAt,
      lastFocusedAt: 0,
      running: phase === 'Running' && status !== 'waiting',
      unread: status === 'waiting',
      hasError: phase === 'Failed' || status === 'error',
      archived: phase === 'Succeeded',
      sizeBytes: 0,
      source: 'k8s',
      // No console deep link for a bare cluster — point this at your own
      // dashboard (Lens, an internal tool, kubectl instructions) if you have one.
      canOpen: false,
      ref: { namespace: pod.metadata.namespace, podName: pod.metadata.name },
    };
  });
}

const cache = createPolledCache(fetchThreads, { ttlMs: 15_000, label: 'k8s-agents' });

export default {
  id: 'k8s-agents',
  name: 'Self-hosted (Kubernetes)',
  async detect() {
    try {
      await coreApi.listNamespacedPod(
        NAMESPACE, undefined, undefined, undefined, undefined,
        LABEL_SELECTOR, undefined, undefined, undefined, 1
      );
      return true;
    } catch {
      return false;
    }
  },
  async scanThreads() {
    return cache.get();
  },
  openThread({ namespace, podName }) {
    return { ok: false, error: `No dashboard configured — pod is ${namespace}/${podName}.` };
  },
  newSession() {
    return { ok: false, error: 'Not applicable for self-hosted pods.' };
  },
};
