// server/platforms/aws-bedrock.mjs
//
// Maps Amazon Bedrock Agents onto bot-crossing's Thread shape.
//
// Two Bedrock APIs are involved:
//  - @aws-sdk/client-bedrock-agent          control plane: ListAgents — the
//    agent *definitions* you've deployed. This is what claims a hex zone.
//  - @aws-sdk/client-bedrock-agent-runtime  ListSessions / ListInvocations —
//    the actual conversations/runs. These become astronauts.
//
// CAVEAT — read before wiring this up: ListSessions returns every session
// in the account; it is not natively scoped to one agent. If you tag
// sessions with the agent name at creation time (sessionMetadata on
// CreateSession) this adapter can join them; otherwise every session lands
// in one "aws:unassigned" zone. If you're actually on Bedrock AgentCore
// (the newer hosted-runtime product) rather than classic Agents-for-Bedrock,
// you want ListAgentRuntimes / ListAgentRuntimeVersions from the AgentCore
// control plane instead — the shapes differ enough that it's a different
// adapter, not a tweak to this one.

import { BedrockAgentClient, ListAgentsCommand } from '@aws-sdk/client-bedrock-agent';
import {
  BedrockAgentRuntimeClient,
  ListSessionsCommand,
  ListInvocationsCommand,
} from '@aws-sdk/client-bedrock-agent-runtime';
import { createPolledCache } from './cache.mjs';

const REGION = process.env.AWS_REGION || 'ap-southeast-2';

const agentClient = new BedrockAgentClient({ region: REGION });
const runtimeClient = new BedrockAgentRuntimeClient({ region: REGION });

async function fetchThreads() {
  const { agentSummaries = [] } = await agentClient.send(new ListAgentsCommand({}));
  const agentsById = new Map(agentSummaries.map((a) => [a.agentId, a]));

  const { sessionSummaries = [] } = await runtimeClient.send(new ListSessionsCommand({}));

  const threads = [];
  for (const session of sessionSummaries) {
    // Best-effort join — see the CAVEAT above.
    const agentId = session.sessionMetadata?.agentId;
    const agent = agentsById.get(agentId);

    let invocationCount = 0;
    let lastInvocationAt = session.lastUpdatedAt;
    try {
      const { invocationSummaries = [] } = await runtimeClient.send(
        new ListInvocationsCommand({ sessionIdentifier: session.sessionId })
      );
      invocationCount = invocationSummaries.length;
      if (invocationSummaries.length) {
        lastInvocationAt = invocationSummaries.at(-1).createdAt;
      }
    } catch {
      // A session with no invocations yet, or a transient throttle — the
      // session summary alone is still worth an astronaut, skip the detail.
    }

    const lastActivityMs = new Date(lastInvocationAt ?? session.lastUpdatedAt).getTime();
    const ageMs = Date.now() - lastActivityMs;

    threads.push({
      id: `aws-bedrock:${session.sessionId}`,
      title: agent?.agentName ?? 'Unassigned session',
      preview: '',
      project: agent ? `aws:${agent.agentName}` : 'aws:unassigned',
      projectPath: '',
      worktree: REGION,
      cwd: '',
      gitBranch: '',
      model: agent?.foundationModel ?? '',
      effort: '',
      createdAt: new Date(session.createdAt).getTime(),
      lastActivityAt: lastActivityMs,
      lastFocusedAt: 0,
      running: session.sessionStatus === 'ACTIVE' && ageMs < 60_000,
      unread: false, // Bedrock sessions don't natively expose a "needs a human" flag
      hasError: session.sessionStatus === 'FAILED',
      archived: session.sessionStatus === 'ENDED' || session.sessionStatus === 'EXPIRED',
      sizeBytes: invocationCount * 4096, // rough proxy so busier sessions look more "built"
      source: 'aws-bedrock',
      canOpen: true,
      ref: { sessionId: session.sessionId, agentId },
    });
  }
  return threads;
}

const cache = createPolledCache(fetchThreads, { ttlMs: 30_000, label: 'aws-bedrock' });

export default {
  id: 'aws-bedrock',
  name: 'AWS Bedrock Agents',
  async detect() {
    try {
      await agentClient.send(new ListAgentsCommand({ maxResults: 1 }));
      return true;
    } catch {
      return false; // no credentials, no access, or the API isn't reachable from here
    }
  },
  async scanThreads() {
    return cache.get();
  },
  openThread({ sessionId }) {
    // The console doesn't deep-link to a single session (yet) — this lands
    // on the agents list. Tighten this if/when AWS ships a session-level URL.
    void sessionId;
    return {
      ok: true,
      url: `https://${REGION}.console.aws.amazon.com/bedrock/home?region=${REGION}#/agents`,
    };
  },
  newSession() {
    return { ok: false, error: 'Starting a new Bedrock session from here is not wired up yet.' };
  },
};
