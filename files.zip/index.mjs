// server/platforms/index.mjs
//
// These four implement the exact same { id, name, detect, scanThreads,
// openThread, newSession } contract as a local harness (see
// server/harnesses/README.md), so nothing in scan.mjs, api.mjs, or
// anywhere under src/ needs to change. Either merge PLATFORMS into
// HARNESSES in server/harnesses/index.mjs, or keep the two lists separate
// and concatenate them wherever scan.mjs currently imports HARNESSES:
//
//   import { HARNESSES } from './harnesses/index.mjs'
//   import { PLATFORMS } from './platforms/index.mjs'
//   export const ALL_SOURCES = [...HARNESSES, ...PLATFORMS]

import awsBedrock from './aws-bedrock.mjs';
import azureAiFoundry from './azure-ai-foundry.mjs';
import gcpVertexAgents from './gcp-vertex-agents.mjs';
import k8sAgents from './k8s-agents.mjs';

export const PLATFORMS = [awsBedrock, azureAiFoundry, gcpVertexAgents, k8sAgents];
